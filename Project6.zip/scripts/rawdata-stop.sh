#!/bin/bash

sudo pkill -f raw_data.py